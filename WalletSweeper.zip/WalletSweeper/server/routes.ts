import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWalletSchema, insertTokenSchema, insertTransactionSchema, insertSweepOperationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Wallet endpoints
  app.get("/api/wallets", async (req, res) => {
    try {
      // For demo purposes, using user ID 1
      const userId = 1;
      const wallets = await storage.getUserWallets(userId);
      res.json(wallets);
    } catch (error) {
      console.error("Error fetching wallets:", error);
      res.status(500).json({ error: "Failed to fetch wallets" });
    }
  });

  app.post("/api/wallets", async (req, res) => {
    try {
      const walletData = insertWalletSchema.parse({
        ...req.body,
        userId: 1 // Demo user ID
      });
      const wallet = await storage.createWallet(walletData);
      res.json(wallet);
    } catch (error) {
      console.error("Error creating wallet:", error);
      res.status(400).json({ error: "Invalid wallet data" });
    }
  });

  app.put("/api/wallets/:id/balance", async (req, res) => {
    try {
      const walletId = parseInt(req.params.id);
      const { balance } = req.body;
      await storage.updateWalletBalance(walletId, balance);
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating wallet balance:", error);
      res.status(500).json({ error: "Failed to update wallet balance" });
    }
  });

  // Token endpoints
  app.get("/api/tokens", async (req, res) => {
    try {
      const userId = 1;
      const tokens = await storage.getUserTokens(userId);
      res.json(tokens);
    } catch (error) {
      console.error("Error fetching tokens:", error);
      res.status(500).json({ error: "Failed to fetch tokens" });
    }
  });

  app.post("/api/tokens", async (req, res) => {
    try {
      const tokenData = insertTokenSchema.parse(req.body);
      const token = await storage.createToken(tokenData);
      res.json(token);
    } catch (error) {
      console.error("Error creating token:", error);
      res.status(400).json({ error: "Invalid token data" });
    }
  });

  app.put("/api/tokens/:id", async (req, res) => {
    try {
      const tokenId = parseInt(req.params.id);
      const { balance, usdValue } = req.body;
      await storage.updateTokenBalance(tokenId, balance, usdValue);
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating token:", error);
      res.status(500).json({ error: "Failed to update token" });
    }
  });

  // Transaction endpoints
  app.get("/api/transactions", async (req, res) => {
    try {
      const userId = 1;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const transactions = await storage.getUserTransactions(userId, limit);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const transactionData = insertTransactionSchema.parse({
        ...req.body,
        userId: 1
      });
      const transaction = await storage.createTransaction(transactionData);
      res.json(transaction);
    } catch (error) {
      console.error("Error creating transaction:", error);
      res.status(400).json({ error: "Invalid transaction data" });
    }
  });

  app.put("/api/transactions/:id/status", async (req, res) => {
    try {
      const transactionId = parseInt(req.params.id);
      const { status, blockNumber } = req.body;
      await storage.updateTransactionStatus(transactionId, status, blockNumber);
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating transaction status:", error);
      res.status(500).json({ error: "Failed to update transaction status" });
    }
  });

  // Sweep operation endpoints
  app.get("/api/sweep-operations", async (req, res) => {
    try {
      const userId = 1;
      const operations = await storage.getUserSweepOperations(userId);
      res.json(operations);
    } catch (error) {
      console.error("Error fetching sweep operations:", error);
      res.status(500).json({ error: "Failed to fetch sweep operations" });
    }
  });

  app.post("/api/sweep-operations", async (req, res) => {
    try {
      const operationData = insertSweepOperationSchema.parse({
        ...req.body,
        userId: 1
      });
      const operation = await storage.createSweepOperation(operationData);
      res.json(operation);
    } catch (error) {
      console.error("Error creating sweep operation:", error);
      res.status(400).json({ error: "Invalid sweep operation data" });
    }
  });

  app.put("/api/sweep-operations/:id/status", async (req, res) => {
    try {
      const operationId = parseInt(req.params.id);
      const { status, transactionHashes } = req.body;
      await storage.updateSweepOperationStatus(operationId, status, transactionHashes);
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating sweep operation status:", error);
      res.status(500).json({ error: "Failed to update sweep operation status" });
    }
  });

  // Web3 utility endpoints
  app.post("/api/web3/estimate-gas", async (req, res) => {
    try {
      const { network, transactions } = req.body;
      
      // Simulate gas estimation based on network
      const baseGas = {
        'ethereum': 21000,
        'bsc': 21000,
        'polygon': 21000
      };

      const gasPrice = {
        'ethereum': '20000000000', // 20 gwei
        'bsc': '5000000000', // 5 gwei
        'polygon': '30000000000' // 30 gwei
      };

      const estimatedGas = baseGas[network as keyof typeof baseGas] || 21000;
      const price = gasPrice[network as keyof typeof gasPrice] || '20000000000';
      
      const totalGasCost = (estimatedGas * parseInt(price) * transactions.length).toString();
      
      res.json({
        estimatedGas,
        gasPrice: price,
        totalGasCost,
        transactionCount: transactions.length
      });
    } catch (error) {
      console.error("Error estimating gas:", error);
      res.status(500).json({ error: "Failed to estimate gas" });
    }
  });

  app.post("/api/web3/token-prices", async (req, res) => {
    try {
      const { tokens } = req.body;
      
      // Simulate token price fetching
      const mockPrices: Record<string, number> = {
        'ETH': 2400,
        'BTC': 43500,
        'BNB': 340,
        'MATIC': 0.85,
        'USDC': 1.00,
        'USDT': 1.00
      };

      const prices = tokens.reduce((acc: Record<string, number>, token: string) => {
        acc[token] = mockPrices[token] || 0;
        return acc;
      }, {});

      res.json(prices);
    } catch (error) {
      console.error("Error fetching token prices:", error);
      res.status(500).json({ error: "Failed to fetch token prices" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
