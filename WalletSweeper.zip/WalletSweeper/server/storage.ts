import { 
  users, wallets, tokens, transactions, sweepOperations,
  type User, type InsertUser,
  type Wallet, type InsertWallet,
  type Token, type InsertToken,
  type Transaction, type InsertTransaction,
  type SweepOperation, type InsertSweepOperation
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Wallet operations
  getUserWallets(userId: number): Promise<Wallet[]>;
  createWallet(wallet: InsertWallet): Promise<Wallet>;
  updateWalletBalance(walletId: number, balance: string): Promise<void>;
  getWalletByAddress(address: string): Promise<Wallet | undefined>;

  // Token operations
  getWalletTokens(walletId: number): Promise<Token[]>;
  getUserTokens(userId: number): Promise<Token[]>;
  createToken(token: InsertToken): Promise<Token>;
  updateTokenBalance(tokenId: number, balance: string, usdValue?: string): Promise<void>;

  // Transaction operations
  getUserTransactions(userId: number, limit?: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransactionStatus(transactionId: number, status: string, blockNumber?: number): Promise<void>;

  // Sweep operations
  getUserSweepOperations(userId: number): Promise<SweepOperation[]>;
  createSweepOperation(operation: InsertSweepOperation): Promise<SweepOperation>;
  updateSweepOperationStatus(operationId: number, status: string, transactionHashes?: string[]): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private wallets: Map<number, Wallet>;
  private tokens: Map<number, Token>;
  private transactions: Map<number, Transaction>;
  private sweepOperations: Map<number, SweepOperation>;
  private currentUserId: number;
  private currentWalletId: number;
  private currentTokenId: number;
  private currentTransactionId: number;
  private currentSweepId: number;

  constructor() {
    this.users = new Map();
    this.wallets = new Map();
    this.tokens = new Map();
    this.transactions = new Map();
    this.sweepOperations = new Map();
    this.currentUserId = 1;
    this.currentWalletId = 1;
    this.currentTokenId = 1;
    this.currentTransactionId = 1;
    this.currentSweepId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getUserWallets(userId: number): Promise<Wallet[]> {
    return Array.from(this.wallets.values()).filter(
      (wallet) => wallet.userId === userId && wallet.isActive
    );
  }

  async createWallet(insertWallet: InsertWallet): Promise<Wallet> {
    const id = this.currentWalletId++;
    const wallet: Wallet = { 
      id, 
      name: insertWallet.name,
      address: insertWallet.address,
      network: insertWallet.network,
      balance: insertWallet.balance || null,
      userId: insertWallet.userId || null,
      isActive: insertWallet.isActive ?? true,
      createdAt: new Date()
    };
    this.wallets.set(id, wallet);
    return wallet;
  }

  async updateWalletBalance(walletId: number, balance: string): Promise<void> {
    const wallet = this.wallets.get(walletId);
    if (wallet) {
      wallet.balance = balance;
      this.wallets.set(walletId, wallet);
    }
  }

  async getWalletByAddress(address: string): Promise<Wallet | undefined> {
    return Array.from(this.wallets.values()).find(
      (wallet) => wallet.address.toLowerCase() === address.toLowerCase()
    );
  }

  async getWalletTokens(walletId: number): Promise<Token[]> {
    return Array.from(this.tokens.values()).filter(
      (token) => token.walletId === walletId
    );
  }

  async getUserTokens(userId: number): Promise<Token[]> {
    const userWallets = await this.getUserWallets(userId);
    const walletIds = userWallets.map(w => w.id);
    return Array.from(this.tokens.values()).filter(
      (token) => token.walletId && walletIds.includes(token.walletId)
    );
  }

  async createToken(insertToken: InsertToken): Promise<Token> {
    const id = this.currentTokenId++;
    const token: Token = { 
      id,
      symbol: insertToken.symbol,
      name: insertToken.name,
      network: insertToken.network,
      balance: insertToken.balance || null,
      walletId: insertToken.walletId || null,
      contractAddress: insertToken.contractAddress || null,
      decimals: insertToken.decimals || null,
      usdValue: insertToken.usdValue || null
    };
    this.tokens.set(id, token);
    return token;
  }

  async updateTokenBalance(tokenId: number, balance: string, usdValue?: string): Promise<void> {
    const token = this.tokens.get(tokenId);
    if (token) {
      token.balance = balance;
      if (usdValue) {
        token.usdValue = usdValue;
      }
      this.tokens.set(tokenId, token);
    }
  }

  async getUserTransactions(userId: number, limit = 50): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter((transaction) => transaction.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentTransactionId++;
    const transaction: Transaction = { 
      id,
      hash: insertTransaction.hash,
      fromAddress: insertTransaction.fromAddress,
      toAddress: insertTransaction.toAddress,
      network: insertTransaction.network,
      status: insertTransaction.status,
      userId: insertTransaction.userId || null,
      amount: insertTransaction.amount || null,
      tokenSymbol: insertTransaction.tokenSymbol || null,
      gasUsed: insertTransaction.gasUsed || null,
      gasPrice: insertTransaction.gasPrice || null,
      blockNumber: insertTransaction.blockNumber || null,
      createdAt: new Date()
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async updateTransactionStatus(transactionId: number, status: string, blockNumber?: number): Promise<void> {
    const transaction = this.transactions.get(transactionId);
    if (transaction) {
      transaction.status = status;
      if (blockNumber) {
        transaction.blockNumber = blockNumber;
      }
      this.transactions.set(transactionId, transaction);
    }
  }

  async getUserSweepOperations(userId: number): Promise<SweepOperation[]> {
    return Array.from(this.sweepOperations.values())
      .filter((operation) => operation.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async createSweepOperation(insertOperation: InsertSweepOperation): Promise<SweepOperation> {
    const id = this.currentSweepId++;
    const operation: SweepOperation = { 
      id,
      sourceWallets: insertOperation.sourceWallets,
      destinationWallet: insertOperation.destinationWallet,
      networks: insertOperation.networks,
      status: insertOperation.status,
      userId: insertOperation.userId || null,
      totalValue: insertOperation.totalValue || null,
      transactionHashes: insertOperation.transactionHashes || null,
      createdAt: new Date(),
      completedAt: null
    };
    this.sweepOperations.set(id, operation);
    return operation;
  }

  async updateSweepOperationStatus(operationId: number, status: string, transactionHashes?: string[]): Promise<void> {
    const operation = this.sweepOperations.get(operationId);
    if (operation) {
      operation.status = status;
      if (transactionHashes) {
        operation.transactionHashes = transactionHashes;
      }
      if (status === 'completed') {
        operation.completedAt = new Date();
      }
      this.sweepOperations.set(operationId, operation);
    }
  }
}

export const storage = new MemStorage();
