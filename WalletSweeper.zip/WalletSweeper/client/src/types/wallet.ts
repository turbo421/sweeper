export interface Network {
  id: string;
  name: string;
  symbol: string;
  rpcUrl: string;
  chainId: number;
  blockExplorerUrl: string;
  color: string;
  description: string;
}

export interface ConnectedWallet {
  address: string;
  name: string;
  balance: string;
  network: string;
  isActive: boolean;
}

export interface TokenBalance {
  symbol: string;
  name: string;
  balance: string;
  decimals: number;
  contractAddress?: string;
  usdValue: string;
  network: string;
  priceChange?: number;
}

export interface WalletProvider {
  name: string;
  icon: string;
  description: string;
  connect: () => Promise<string>;
  disconnect: () => Promise<void>;
  getBalance: (address: string, network: string) => Promise<string>;
  getTokens: (address: string, network: string) => Promise<TokenBalance[]>;
  sendTransaction: (transaction: TransactionRequest) => Promise<string>;
}

export interface TransactionRequest {
  to: string;
  value?: string;
  data?: string;
  gasLimit?: string;
  gasPrice?: string;
}

export interface TransactionStatus {
  hash: string;
  status: 'pending' | 'confirmed' | 'failed';
  blockNumber?: number;
  gasUsed?: string;
  confirmations: number;
}

export interface SweepOperation {
  id: string;
  sourceWallets: string[];
  destinationWallet: string;
  networks: string[];
  tokens: TokenBalance[];
  status: 'initiated' | 'in_progress' | 'completed' | 'failed';
  transactionHashes: string[];
  totalValue: string;
  gasEstimate: string;
  createdAt: Date;
  completedAt?: Date;
}

export interface GasEstimation {
  estimatedGas: number;
  gasPrice: string;
  totalGasCost: string;
  transactionCount: number;
}
