import { Network } from '@/types/wallet';

export const SUPPORTED_NETWORKS: Network[] = [
  {
    id: 'ethereum',
    name: 'Ethereum',
    symbol: 'ETH',
    rpcUrl: 'https://mainnet.infura.io/v3/YOUR_INFURA_KEY',
    chainId: 1,
    blockExplorerUrl: 'https://etherscan.io',
    color: '#3C3C3D',
    description: 'The original smart contract platform'
  },
  {
    id: 'bsc',
    name: 'BNB Smart Chain',
    symbol: 'BNB',
    rpcUrl: 'https://bsc-dataseed.binance.org/',
    chainId: 56,
    blockExplorerUrl: 'https://bscscan.com',
    color: '#F0B90B',
    description: 'Low fees, high throughput'
  },
  {
    id: 'polygon',
    name: 'Polygon',
    symbol: 'MATIC',
    rpcUrl: 'https://polygon-rpc.com/',
    chainId: 137,
    blockExplorerUrl: 'https://polygonscan.com',
    color: '#8247E5',
    description: 'Scalable Ethereum solution'
  }
];

export const getNetworkById = (id: string): Network | undefined => {
  return SUPPORTED_NETWORKS.find(network => network.id === id);
};

export const getNetworkByChainId = (chainId: number): Network | undefined => {
  return SUPPORTED_NETWORKS.find(network => network.chainId === chainId);
};

export const METAMASK_ORANGE = '#f6851b';
export const DARK_NAVY = '#24272a';
export const DARK_BLUE = '#2a2d31';
export const ROYAL_BLUE = '#3c4043';
