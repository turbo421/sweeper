import { ethers } from 'ethers';
import { TokenBalance, ConnectedWallet, Network } from '@/types/wallet';
import { getNetworkById } from './web3-config';

// ERC-20 Token ABI (minimal for transfers)
const ERC20_ABI = [
  'function balanceOf(address owner) view returns (uint256)',
  'function transfer(address to, uint256 amount) returns (bool)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
  'function name() view returns (string)'
];

export interface SweepTransaction {
  hash: string;
  status: 'pending' | 'confirmed' | 'failed';
  token: TokenBalance;
  amount: string;
  gasUsed?: string;
}

export interface SweepResult {
  success: boolean;
  transactions: SweepTransaction[];
  totalGasUsed: string;
  errors: string[];
}

export class SweepManager {
  private provider: ethers.BrowserProvider;

  constructor() {
    if (!window.ethereum) {
      throw new Error('MetaMask not found');
    }
    this.provider = new ethers.BrowserProvider(window.ethereum);
  }

  private async getSigner(): Promise<ethers.JsonRpcSigner> {
    return await this.provider.getSigner();
  }

  async estimateGasForSweep(
    tokens: TokenBalance[],
    destinationAddress: string,
    sourceWallets: ConnectedWallet[]
  ): Promise<{ totalGas: bigint; gasPrice: bigint; totalCost: string }> {
    const gasPrice = await this.provider.getFeeData();
    let totalGas = BigInt(0);

    for (const token of tokens) {
      try {
        if (token.contractAddress) {
          // ERC-20 token transfer
          const signer = await this.getSigner();
          const contract = new ethers.Contract(token.contractAddress, ERC20_ABI, signer);
          const gasEstimate = await contract.transfer.estimateGas(
            destinationAddress,
            ethers.parseUnits(token.balance, token.decimals)
          );
          totalGas += gasEstimate;
        } else {
          // Native token transfer
          const gasEstimate = await this.provider.estimateGas({
            to: destinationAddress,
            value: ethers.parseEther(token.balance)
          });
          totalGas += gasEstimate;
        }
      } catch (error) {
        console.error(`Error estimating gas for ${token.symbol}:`, error);
        // Add buffer gas for failed estimates
        totalGas += BigInt(21000);
      }
    }

    const effectiveGasPrice = gasPrice.gasPrice || BigInt(20000000000); // 20 gwei fallback
    const totalCost = ethers.formatEther(totalGas * effectiveGasPrice);

    return {
      totalGas,
      gasPrice: effectiveGasPrice,
      totalCost
    };
  }

  async sweepTokens(
    tokens: TokenBalance[],
    destinationAddress: string,
    onTransactionUpdate?: (transaction: SweepTransaction) => void
  ): Promise<SweepResult> {
    const transactions: SweepTransaction[] = [];
    const errors: string[] = [];
    let totalGasUsed = BigInt(0);

    for (const token of tokens) {
      try {
        let txHash: string;
        
        if (token.contractAddress) {
          // Handle ERC-20 token
          txHash = await this.sweepERC20Token(token, destinationAddress);
        } else {
          // Handle native token (ETH, BNB, MATIC)
          txHash = await this.sweepNativeToken(token, destinationAddress);
        }

        const transaction: SweepTransaction = {
          hash: txHash,
          status: 'pending',
          token,
          amount: token.balance
        };

        transactions.push(transaction);
        onTransactionUpdate?.(transaction);

        // Wait for transaction confirmation
        const receipt = await this.provider.waitForTransaction(txHash);
        
        if (receipt) {
          transaction.status = receipt.status === 1 ? 'confirmed' : 'failed';
          transaction.gasUsed = receipt.gasUsed.toString();
          totalGasUsed += receipt.gasUsed;
          onTransactionUpdate?.(transaction);
        }

      } catch (error: any) {
        console.error(`Error sweeping ${token.symbol}:`, error);
        errors.push(`Failed to sweep ${token.symbol}: ${error.message}`);
        
        const failedTransaction: SweepTransaction = {
          hash: '',
          status: 'failed',
          token,
          amount: token.balance
        };
        transactions.push(failedTransaction);
        onTransactionUpdate?.(failedTransaction);
      }
    }

    return {
      success: errors.length === 0,
      transactions,
      totalGasUsed: ethers.formatEther(totalGasUsed * BigInt(20000000000)), // Approximate cost
      errors
    };
  }

  private async sweepERC20Token(token: TokenBalance, destinationAddress: string): Promise<string> {
    if (!token.contractAddress) {
      throw new Error('Contract address required for ERC-20 token');
    }

    const signer = await this.getSigner();
    const contract = new ethers.Contract(token.contractAddress, ERC20_ABI, signer);
    const amount = ethers.parseUnits(token.balance, token.decimals);

    // Check if we need to approve first (for some tokens)
    try {
      const tx = await contract.transfer(destinationAddress, amount);
      return tx.hash;
    } catch (error: any) {
      if (error.message.includes('allowance') || error.message.includes('approve')) {
        // If transfer fails due to allowance, try approve first
        const approveTx = await contract.approve(destinationAddress, amount);
        await approveTx.wait();
        
        const transferTx = await contract.transfer(destinationAddress, amount);
        return transferTx.hash;
      }
      throw error;
    }
  }

  private async sweepNativeToken(token: TokenBalance, destinationAddress: string): Promise<string> {
    const signer = await this.getSigner();
    const balance = ethers.parseEther(token.balance);
    
    // Reserve some ETH for gas
    const gasLimit = BigInt(21000);
    const gasPrice = (await this.provider.getFeeData()).gasPrice || BigInt(20000000000);
    const gasReserve = gasLimit * gasPrice;
    
    const transferAmount = balance - gasReserve;
    
    if (transferAmount <= 0) {
      throw new Error('Insufficient balance to cover gas fees');
    }

    const tx = await signer.sendTransaction({
      to: destinationAddress,
      value: transferAmount,
      gasLimit: gasLimit
    });

    return tx.hash;
  }

  async switchToNetwork(network: Network): Promise<void> {
    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${network.chainId.toString(16)}` }],
      });
    } catch (error: any) {
      if (error.code === 4902) {
        // Network not added to MetaMask, add it
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: `0x${network.chainId.toString(16)}`,
            chainName: network.name,
            nativeCurrency: {
              name: network.symbol,
              symbol: network.symbol,
              decimals: 18,
            },
            rpcUrls: [network.rpcUrl],
            blockExplorerUrls: [network.blockExplorerUrl],
          }],
        });
      } else {
        throw error;
      }
    }
  }

  async getCurrentNetwork(): Promise<Network | null> {
    try {
      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      const networkId = parseInt(chainId, 16);
      
      // Find matching network
      const networks = [
        { id: 'ethereum', chainId: 1 },
        { id: 'bsc', chainId: 56 },
        { id: 'polygon', chainId: 137 }
      ];
      
      const network = networks.find(n => n.chainId === networkId);
      return network ? getNetworkById(network.id) || null : null;
    } catch (error) {
      console.error('Error getting current network:', error);
      return null;
    }
  }
}

export const createSweepManager = () => {
  return new SweepManager();
};