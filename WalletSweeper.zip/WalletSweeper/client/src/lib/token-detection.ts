import { TokenBalance, Network } from '@/types/wallet';
import { ethers } from 'ethers';

// ERC-20 ABI for basic token operations
const ERC20_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
  'function balanceOf(address) view returns (uint256)',
  'function totalSupply() view returns (uint256)'
];

// Common token addresses for each network
const COMMON_TOKENS: Record<string, Array<{address: string, symbol: string, name: string}>> = {
  ethereum: [
    { address: '0xA0b86a33E6417aFE4cc0D4A2Cc4c4B1E7bE5f8e1', symbol: 'USDC', name: 'USD Coin' },
    { address: '0xdAC17F958D2ee523a2206206994597C13D831ec7', symbol: 'USDT', name: 'Tether USD' },
    { address: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599', symbol: 'WBTC', name: 'Wrapped Bitcoin' }
  ],
  bsc: [
    { address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', symbol: 'USDC', name: 'USD Coin' },
    { address: '0x55d398326f99059fF775485246999027B3197955', symbol: 'USDT', name: 'Tether USD' },
    { address: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c', symbol: 'BTCB', name: 'Bitcoin BEP2' }
  ],
  polygon: [
    { address: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174', symbol: 'USDC', name: 'USD Coin' },
    { address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', symbol: 'USDT', name: 'Tether USD' },
    { address: '0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6', symbol: 'WBTC', name: 'Wrapped Bitcoin' }
  ]
};

export async function detectTokens(
  walletAddress: string, 
  network: Network
): Promise<TokenBalance[]> {
  try {
    const provider = new ethers.JsonRpcProvider(network.rpcUrl);
    const tokens: TokenBalance[] = [];
    
    // Get native token balance
    const nativeBalance = await provider.getBalance(walletAddress);
    tokens.push({
      symbol: network.symbol,
      name: network.name,
      balance: ethers.formatEther(nativeBalance),
      decimals: 18,
      usdValue: '0',
      network: network.id
    });

    // Check common tokens for this network
    const commonTokens = COMMON_TOKENS[network.id] || [];
    
    for (const tokenInfo of commonTokens) {
      try {
        const contract = new ethers.Contract(tokenInfo.address, ERC20_ABI, provider);
        const balance = await contract.balanceOf(walletAddress);
        const decimals = await contract.decimals();
        
        if (balance > 0) {
          tokens.push({
            symbol: tokenInfo.symbol,
            name: tokenInfo.name,
            balance: ethers.formatUnits(balance, decimals),
            decimals,
            contractAddress: tokenInfo.address,
            usdValue: '0',
            network: network.id
          });
        }
      } catch (error) {
        console.warn(`Failed to get balance for token ${tokenInfo.symbol}:`, error);
      }
    }

    return tokens;
  } catch (error) {
    console.error('Error detecting tokens:', error);
    return [];
  }
}

export async function getTokenPrices(tokens: string[]): Promise<Record<string, number>> {
  try {
    const response = await fetch('/api/web3/token-prices', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ tokens }),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch token prices');
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching token prices:', error);
    return {};
  }
}

export function calculatePortfolioValue(tokens: TokenBalance[]): string {
  const total = tokens.reduce((sum, token) => {
    const balance = parseFloat(token.balance) || 0;
    const price = parseFloat(token.usdValue) || 0;
    return sum + (balance * price);
  }, 0);
  
  return total.toFixed(2);
}
