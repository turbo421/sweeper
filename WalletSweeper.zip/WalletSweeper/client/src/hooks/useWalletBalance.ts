import { useState, useEffect, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { TokenBalance } from '@/types/wallet';
import { detectTokens, getTokenPrices, calculatePortfolioValue } from '@/lib/token-detection';
import { SUPPORTED_NETWORKS } from '@/lib/web3-config';

export function useWalletBalance(walletAddress?: string) {
  const [totalPortfolioValue, setTotalPortfolioValue] = useState('0');
  const queryClient = useQueryClient();

  const { data: tokens = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/tokens'],
    enabled: !!walletAddress,
  });

  const { data: wallets = [] } = useQuery({
    queryKey: ['/api/wallets'],
    enabled: !!walletAddress,
  });

  const refreshBalances = useCallback(async () => {
    if (!walletAddress) return;

    try {
      const allTokens: TokenBalance[] = [];
      
      // Detect tokens across all supported networks
      for (const network of SUPPORTED_NETWORKS) {
        const networkTokens = await detectTokens(walletAddress, network);
        allTokens.push(...networkTokens);
      }

      // Get current prices for all tokens
      const tokenSymbols = [...new Set(allTokens.map(token => token.symbol))];
      const prices = await getTokenPrices(tokenSymbols);

      // Update tokens with current prices
      const tokensWithPrices = allTokens.map(token => ({
        ...token,
        usdValue: (parseFloat(token.balance) * (prices[token.symbol] || 0)).toFixed(2)
      }));

      // Update backend with new token data
      for (const token of tokensWithPrices) {
        await fetch('/api/tokens', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            walletId: 1, // Demo wallet ID
            symbol: token.symbol,
            name: token.name,
            contractAddress: token.contractAddress,
            balance: token.balance,
            decimals: token.decimals,
            network: token.network,
            usdValue: token.usdValue
          }),
        });
      }

      // Calculate total portfolio value
      const totalValue = calculatePortfolioValue(tokensWithPrices);
      setTotalPortfolioValue(totalValue);

      // Invalidate and refetch queries
      queryClient.invalidateQueries({ queryKey: ['/api/tokens'] });
      queryClient.invalidateQueries({ queryKey: ['/api/wallets'] });

    } catch (error) {
      console.error('Error refreshing balances:', error);
    }
  }, [walletAddress, queryClient]);

  const getTokensByNetwork = useCallback((networkId: string): TokenBalance[] => {
    return tokens.filter((token: any) => token.network === networkId);
  }, [tokens]);

  const getWalletsByNetwork = useCallback((networkId: string) => {
    return wallets.filter((wallet: any) => wallet.network === networkId);
  }, [wallets]);

  const getTotalTokenValue = useCallback((tokenSymbol: string): string => {
    const tokenBalances = tokens.filter((token: any) => token.symbol === tokenSymbol);
    const totalBalance = tokenBalances.reduce((sum: number, token: any) => {
      return sum + parseFloat(token.balance || '0');
    }, 0);
    
    const totalValue = tokenBalances.reduce((sum: number, token: any) => {
      return sum + parseFloat(token.usdValue || '0');
    }, 0);
    
    return totalValue.toFixed(2);
  }, [tokens]);

  const getNetworkStats = useCallback(() => {
    const stats = SUPPORTED_NETWORKS.map(network => {
      const networkTokens = getTokensByNetwork(network.id);
      const networkWallets = getWalletsByNetwork(network.id);
      const totalValue = networkTokens.reduce((sum: number, token: any) => {
        return sum + parseFloat(token.usdValue || '0');
      }, 0);

      return {
        network: network.name,
        id: network.id,
        walletCount: networkWallets.length,
        tokenCount: networkTokens.length,
        totalValue: totalValue.toFixed(2)
      };
    });

    return stats;
  }, [getTokensByNetwork, getWalletsByNetwork]);

  useEffect(() => {
    if (walletAddress && tokens.length === 0) {
      refreshBalances();
    }
  }, [walletAddress, tokens.length, refreshBalances]);

  return {
    tokens,
    wallets,
    totalPortfolioValue,
    isLoading,
    refreshBalances,
    refetch,
    getTokensByNetwork,
    getWalletsByNetwork,
    getTotalTokenValue,
    getNetworkStats
  };
}
