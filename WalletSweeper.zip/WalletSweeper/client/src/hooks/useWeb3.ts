import { useState, useCallback, useEffect } from 'react';
import { ethers } from 'ethers';
import { WalletProvider, ConnectedWallet, Network } from '@/types/wallet';
import { SUPPORTED_NETWORKS, getNetworkByChainId } from '@/lib/web3-config';
import { useToast } from '@/hooks/use-toast';

declare global {
  interface Window {
    ethereum?: any;
  }
}

export function useWeb3() {
  const [isConnected, setIsConnected] = useState(false);
  const [connectedWallets, setConnectedWallets] = useState<ConnectedWallet[]>([]);
  const [currentNetwork, setCurrentNetwork] = useState<Network | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();

  const checkConnection = useCallback(async () => {
    if (typeof window !== 'undefined' && window.ethereum) {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        if (accounts.length > 0) {
          const chainId = await window.ethereum.request({ method: 'eth_chainId' });
          const network = getNetworkByChainId(parseInt(chainId, 16));
          
          setIsConnected(true);
          setCurrentNetwork(network || SUPPORTED_NETWORKS[0]);
          
          // Get balance for connected wallet
          const provider = new ethers.BrowserProvider(window.ethereum);
          const balance = await provider.getBalance(accounts[0]);
          
          setConnectedWallets([{
            address: accounts[0],
            name: 'MetaMask Wallet',
            balance: ethers.formatEther(balance),
            network: network?.name || 'Unknown',
            isActive: true
          }]);
        }
      } catch (error) {
        console.error('Error checking connection:', error);
      }
    }
  }, []);

  const connectMetaMask = useCallback(async (): Promise<string> => {
    if (!window.ethereum) {
      toast({
        title: "MetaMask Not Found",
        description: "Please install MetaMask to connect your wallet.",
        variant: "destructive",
      });
      throw new Error('MetaMask not found');
    }

    setIsConnecting(true);
    try {
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts',
      });

      if (accounts.length === 0) {
        throw new Error('No accounts found');
      }

      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      const network = getNetworkByChainId(parseInt(chainId, 16));
      
      setIsConnected(true);
      setCurrentNetwork(network || SUPPORTED_NETWORKS[0]);

      // Get balance
      const provider = new ethers.BrowserProvider(window.ethereum);
      const balance = await provider.getBalance(accounts[0]);
      
      const newWallet: ConnectedWallet = {
        address: accounts[0],
        name: 'MetaMask Wallet',
        balance: ethers.formatEther(balance),
        network: network?.name || 'Unknown',
        isActive: true
      };

      setConnectedWallets([newWallet]);

      toast({
        title: "Wallet Connected",
        description: `Successfully connected to ${accounts[0].slice(0, 6)}...${accounts[0].slice(-4)}`,
      });

      return accounts[0];
    } catch (error: any) {
      console.error('Error connecting to MetaMask:', error);
      toast({
        title: "Connection Failed",
        description: error.message || "Failed to connect to MetaMask",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsConnecting(false);
    }
  }, [toast]);

  const switchNetwork = useCallback(async (network: Network) => {
    if (!window.ethereum) {
      throw new Error('MetaMask not found');
    }

    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${network.chainId.toString(16)}` }],
      });
      
      setCurrentNetwork(network);
      
      toast({
        title: "Network Switched",
        description: `Switched to ${network.name}`,
      });
    } catch (error: any) {
      if (error.code === 4902) {
        // Network not added to MetaMask
        try {
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [{
              chainId: `0x${network.chainId.toString(16)}`,
              chainName: network.name,
              nativeCurrency: {
                name: network.symbol,
                symbol: network.symbol,
                decimals: 18,
              },
              rpcUrls: [network.rpcUrl],
              blockExplorerUrls: [network.blockExplorerUrl],
            }],
          });
          
          setCurrentNetwork(network);
          
          toast({
            title: "Network Added",
            description: `Added and switched to ${network.name}`,
          });
        } catch (addError) {
          console.error('Error adding network:', addError);
          toast({
            title: "Failed to Add Network",
            description: "Could not add the network to MetaMask",
            variant: "destructive",
          });
        }
      } else {
        console.error('Error switching network:', error);
        toast({
          title: "Failed to Switch Network",
          description: error.message || "Could not switch network",
          variant: "destructive",
        });
      }
    }
  }, [toast]);

  const disconnect = useCallback(async () => {
    setIsConnected(false);
    setConnectedWallets([]);
    setCurrentNetwork(null);
    
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected",
    });
  }, [toast]);

  const addWallet = useCallback(async (address: string, name: string, network: string) => {
    try {
      const response = await fetch('/api/wallets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          address,
          name,
          network,
          balance: '0'
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to add wallet');
      }

      const wallet = await response.json();
      return wallet;
    } catch (error) {
      console.error('Error adding wallet:', error);
      throw error;
    }
  }, []);

  useEffect(() => {
    checkConnection();

    // Listen for account changes
    if (window.ethereum) {
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length === 0) {
          disconnect();
        } else {
          checkConnection();
        }
      };

      const handleChainChanged = () => {
        checkConnection();
      };

      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);

      return () => {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        window.ethereum.removeListener('chainChanged', handleChainChanged);
      };
    }
  }, [checkConnection, disconnect]);

  return {
    isConnected,
    connectedWallets,
    currentNetwork,
    isConnecting,
    connectMetaMask,
    switchNetwork,
    disconnect,
    addWallet,
    supportedNetworks: SUPPORTED_NETWORKS
  };
}
