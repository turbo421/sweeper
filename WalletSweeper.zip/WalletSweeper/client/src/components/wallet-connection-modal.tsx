import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Wallet, 
  Smartphone, 
  CreditCard, 
  ChevronRight,
  AlertTriangle,
  Loader2
} from "lucide-react";

interface WalletConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnectMetaMask: () => Promise<string>;
  isConnecting: boolean;
}

export default function WalletConnectionModal({ 
  isOpen, 
  onClose, 
  onConnectMetaMask,
  isConnecting 
}: WalletConnectionModalProps) {
  const handleConnectMetaMask = async () => {
    try {
      await onConnectMetaMask();
      onClose();
    } catch (error) {
      console.error('Failed to connect MetaMask:', error);
    }
  };

  const walletOptions = [
    {
      name: "MetaMask",
      description: "Connect using browser extension",
      icon: Wallet,
      color: "bg-primary",
      onClick: handleConnectMetaMask
    },
    {
      name: "WalletConnect",
      description: "Connect using mobile wallet",
      icon: Smartphone,
      color: "bg-blue-500",
      onClick: () => {
        // TODO: Implement WalletConnect
        console.log("WalletConnect not implemented yet");
      }
    },
    {
      name: "Coinbase Wallet",
      description: "Connect using Coinbase",
      icon: CreditCard,
      color: "bg-blue-600",
      onClick: () => {
        // TODO: Implement Coinbase Wallet
        console.log("Coinbase Wallet not implemented yet");
      }
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-dark-blue border-gray-600/50">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white">
            Connect Your Wallet
          </DialogTitle>
        </DialogHeader>
        
        <p className="text-gray-400 mb-6">
          Choose your preferred wallet to start managing your assets
        </p>
        
        <div className="space-y-4">
          {walletOptions.map((option) => {
            const Icon = option.icon;
            return (
              <Button
                key={option.name}
                variant="outline"
                className="w-full p-4 h-auto border-gray-600/50 hover:border-primary/50 hover:bg-primary/5 transition-all justify-start"
                onClick={option.onClick}
                disabled={isConnecting}
              >
                <div className="flex items-center gap-4 w-full">
                  <div className={`w-12 h-12 ${option.color} rounded-xl flex items-center justify-center`}>
                    {isConnecting && option.name === "MetaMask" ? (
                      <Loader2 className="w-6 h-6 text-white animate-spin" />
                    ) : (
                      <Icon className="w-6 h-6 text-white" />
                    )}
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-semibold text-white">{option.name}</p>
                    <p className="text-sm text-gray-400">{option.description}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              </Button>
            );
          })}
        </div>
        
        <Alert className="mt-6 bg-yellow-500/10 border-yellow-500/20">
          <AlertTriangle className="w-5 h-5 text-yellow-500" />
          <AlertDescription className="text-yellow-300">
            <p className="font-medium">Security Notice</p>
            <p className="text-xs mt-1 text-yellow-400">
              Never share your private keys. This application only reads public wallet data.
            </p>
          </AlertDescription>
        </Alert>
      </DialogContent>
    </Dialog>
  );
}
