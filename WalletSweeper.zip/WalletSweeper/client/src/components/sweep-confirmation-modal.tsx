import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { TokenBalance, ConnectedWallet } from "@/types/wallet";
import { createSweepManager, SweepTransaction } from "@/lib/sweep-operations";
import { useToast } from "@/hooks/use-toast";
import { 
  Package, 
  Zap, 
  Check,
  X,
  Loader2,
  AlertTriangle,
  ArrowRight,
  Wallet
} from "lucide-react";

interface SweepConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExecute: () => void;
  tokens: TokenBalance[];
  selectedNetworks: string[];
  connectedWallets: ConnectedWallet[];
}

export default function SweepConfirmationModal({ 
  isOpen, 
  onClose, 
  onExecute, 
  tokens, 
  selectedNetworks,
  connectedWallets 
}: SweepConfirmationModalProps) {
  const [destinationWallet, setDestinationWallet] = useState<string>("");
  const [customAddress, setCustomAddress] = useState<string>("");
  const [isExecuting, setIsExecuting] = useState(false);
  const [gasEstimate, setGasEstimate] = useState({
    totalGas: BigInt(0),
    gasPrice: BigInt(0),
    totalCost: "0"
  });
  const [sweepTransactions, setSweepTransactions] = useState<SweepTransaction[]>([]);
  const { toast } = useToast();

  // Filter tokens for selected networks
  const tokensToSweep = tokens.filter(token => 
    selectedNetworks.includes(token.network)
  );

  const totalValue = tokensToSweep.reduce((sum, token) => 
    sum + parseFloat(token.usdValue || '0'), 0
  );

  useEffect(() => {
    if (isOpen && tokensToSweep.length > 0 && destinationWallet && destinationWallet !== 'custom') {
      estimateGas();
    }
  }, [isOpen, tokensToSweep, destinationWallet]);

  const estimateGas = async () => {
    try {
      const sweepManager = createSweepManager();
      const finalDestination = destinationWallet === 'custom' ? customAddress : destinationWallet;
      
      if (!finalDestination) return;

      const estimate = await sweepManager.estimateGasForSweep(
        tokensToSweep,
        finalDestination,
        connectedWallets
      );
      
      setGasEstimate(estimate);
    } catch (error) {
      console.error('Gas estimation failed:', error);
    }
  };

  const handleExecute = async () => {
    const finalDestination = destinationWallet === 'custom' ? customAddress : destinationWallet;
    
    if (!finalDestination) {
      toast({
        title: "Destination Required",
        description: "Please select or enter a destination wallet address.",
        variant: "destructive"
      });
      return;
    }

    if (destinationWallet === 'custom' && !customAddress.match(/^0x[a-fA-F0-9]{40}$/)) {
      toast({
        title: "Invalid Address",
        description: "Please enter a valid Ethereum address.",
        variant: "destructive"
      });
      return;
    }

    setIsExecuting(true);
    setSweepTransactions([]);
    
    try {
      const sweepManager = createSweepManager();
      
      toast({
        title: "Starting Sweep",
        description: "Please approve transactions in MetaMask as they appear.",
      });

      const result = await sweepManager.sweepTokens(
        tokensToSweep,
        finalDestination,
        (transaction) => {
          setSweepTransactions(prev => {
            const index = prev.findIndex(tx => tx.hash === transaction.hash || tx.token.symbol === transaction.token.symbol);
            if (index >= 0) {
              const updated = [...prev];
              updated[index] = transaction;
              return updated;
            }
            return [...prev, transaction];
          });
        }
      );

      if (result.success) {
        toast({
          title: "Sweep Completed",
          description: `Successfully swept all tokens. Total gas used: ${result.totalGasUsed} ETH`,
        });
        onExecute();
        setTimeout(() => onClose(), 2000);
      } else {
        toast({
          title: "Sweep Partially Failed",
          description: `Some transactions failed: ${result.errors.join(', ')}`,
          variant: "destructive"
        });
      }
    } catch (error: any) {
      console.error('Sweep failed:', error);
      toast({
        title: "Sweep Failed",
        description: error.message || "Failed to execute sweep operation. Make sure MetaMask is connected.",
        variant: "destructive"
      });
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl bg-dark-blue border-gray-600/50 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white flex items-center gap-3">
            <Package className="w-6 h-6 text-primary" />
            Confirm Sweep Operation
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Summary Card */}
          <Card className="bg-dark-navy border-gray-600/50">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-gray-400 text-sm">Total Tokens</p>
                  <p className="text-2xl font-bold text-white">{tokensToSweep.length}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Total Value</p>
                  <p className="text-2xl font-bold text-green-400">${totalValue.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Networks</p>
                  <p className="text-2xl font-bold text-blue-400">{selectedNetworks.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Destination Selection */}
          <div className="space-y-4">
            <Label className="text-white text-lg font-semibold">Destination Wallet</Label>
            <Select value={destinationWallet} onValueChange={setDestinationWallet}>
              <SelectTrigger className="bg-dark-navy border-gray-600/50 text-white">
                <SelectValue placeholder="Select destination wallet" />
              </SelectTrigger>
              <SelectContent className="bg-dark-navy border-gray-600/50">
                {connectedWallets.map((wallet) => (
                  <SelectItem key={wallet.address} value={wallet.address} className="text-white">
                    <div className="flex items-center gap-3">
                      <Wallet className="w-4 h-4" />
                      <div>
                        <p className="font-medium">{wallet.name}</p>
                        <p className="text-xs text-gray-400">{wallet.address.slice(0, 8)}...{wallet.address.slice(-6)}</p>
                      </div>
                    </div>
                  </SelectItem>
                ))}
                <SelectItem value="custom" className="text-white">
                  <div className="flex items-center gap-3">
                    <Package className="w-4 h-4" />
                    <span>Custom Address</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>

            {destinationWallet === 'custom' && (
              <div className="space-y-2">
                <Label className="text-white">Custom Wallet Address</Label>
                <Input
                  value={customAddress}
                  onChange={(e) => setCustomAddress(e.target.value)}
                  placeholder="0x..."
                  className="bg-dark-navy border-gray-600/50 text-white"
                />
              </div>
            )}
          </div>

          {/* Gas Estimation */}
          {gasEstimate.totalCost !== "0" && (
            <Card className="bg-dark-navy border-gray-600/50">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    <span className="text-white font-medium">Estimated Gas Cost</span>
                  </div>
                  <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                    ~{gasEstimate.totalCost} ETH
                  </Badge>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Transaction Progress */}
          {isExecuting && sweepTransactions.length > 0 && (
            <Card className="bg-dark-navy border-gray-600/50">
              <CardContent className="p-4">
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Transaction Progress
                </h3>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {sweepTransactions.map((tx, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-dark-blue rounded">
                      <div className="flex items-center gap-3">
                        {tx.status === 'pending' && <Loader2 className="w-4 h-4 animate-spin text-yellow-400" />}
                        {tx.status === 'confirmed' && <Check className="w-4 h-4 text-green-400" />}
                        {tx.status === 'failed' && <X className="w-4 h-4 text-red-400" />}
                        <span className="text-white text-sm">{tx.token.symbol}</span>
                      </div>
                      <Badge 
                        variant="outline" 
                        className={
                          tx.status === 'confirmed' ? 'text-green-400 border-green-400' :
                          tx.status === 'failed' ? 'text-red-400 border-red-400' :
                          'text-yellow-400 border-yellow-400'
                        }
                      >
                        {tx.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Tokens to Sweep */}
          <div className="space-y-3">
            <Label className="text-white text-lg font-semibold">Tokens to Sweep ({tokensToSweep.length})</Label>
            <div className="grid gap-3 max-h-60 overflow-y-auto">
              {tokensToSweep.map((token, index) => (
                <Card key={index} className="bg-dark-navy border-gray-600/50">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-sm">{token.symbol[0]}</span>
                        </div>
                        <div>
                          <p className="text-white font-medium">{token.symbol}</p>
                          <p className="text-gray-400 text-sm">{token.network}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-medium">{parseFloat(token.balance).toFixed(4)}</p>
                        <p className="text-gray-400 text-sm">${token.usdValue}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Warning */}
          <Alert className="bg-yellow-500/10 border-yellow-500/20">
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            <AlertDescription className="text-yellow-300">
              <p className="font-medium">Important Security Notice</p>
              <p className="text-xs mt-1 text-yellow-400">
                This operation will transfer all selected tokens to the destination wallet. 
                Please verify the destination address carefully before proceeding.
              </p>
            </AlertDescription>
          </Alert>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isExecuting}
              className="flex-1 bg-transparent border-gray-600/50 text-white hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button
              onClick={handleExecute}
              disabled={!destinationWallet || isExecuting || (destinationWallet === 'custom' && !customAddress)}
              className="flex-1 bg-primary hover:bg-primary/90 text-white"
            >
              {isExecuting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Executing Sweep...
                </>
              ) : (
                <>
                  <ArrowRight className="w-4 h-4 mr-2" />
                  Execute Sweep
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}