import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Network } from "@/types/wallet";
import { Globe, Search } from "lucide-react";

interface NetworkSelectorProps {
  supportedNetworks: Network[];
  selectedNetworks: string[];
  onNetworkToggle: (networkId: string) => void;
  networkStats: Array<{
    network: string;
    id: string;
    walletCount: number;
    tokenCount: number;
    totalValue: string;
  }>;
  onScanNetworks: () => void;
}

export default function NetworkSelector({
  supportedNetworks,
  selectedNetworks,
  onNetworkToggle,
  networkStats,
  onScanNetworks
}: NetworkSelectorProps) {
  return (
    <Card className="bg-gradient-to-br from-dark-blue to-royal-blue border-gray-600/30 shadow-2xl">
      <CardHeader>
        <CardTitle className="text-2xl font-bold mb-6 flex items-center gap-3 text-white">
          <Globe className="w-7 h-7 text-primary" />
          Select Networks to Sweep
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {supportedNetworks.map((network) => {
          const stats = networkStats.find(s => s.id === network.id);
          const isSelected = selectedNetworks.includes(network.id);
          
          return (
            <div
              key={network.id}
              className="network-selector p-4 rounded-xl border border-gray-600/50 hover:border-primary/50 transition-all cursor-pointer bg-gray-700/20"
              onClick={() => onNetworkToggle(network.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-sm"
                    style={{ backgroundColor: network.color }}
                  >
                    {network.symbol}
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">{network.name}</h4>
                    <p className="text-sm text-gray-400">{network.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <Badge variant="secondary" className="text-xs mb-1">
                      {stats?.walletCount || 0} wallets
                    </Badge>
                    <p className="text-xs text-gray-400">
                      {stats?.tokenCount || 0} tokens
                    </p>
                    {stats?.totalValue && parseFloat(stats.totalValue) > 0 && (
                      <p className="text-xs text-green-400">
                        ${stats.totalValue}
                      </p>
                    )}
                  </div>
                  <Checkbox
                    checked={isSelected}
                    onCheckedChange={() => onNetworkToggle(network.id)}
                    className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                  />
                </div>
              </div>
            </div>
          );
        })}
        
        <Button
          onClick={onScanNetworks}
          className="w-full mt-6 bg-primary hover:bg-primary/90 text-white py-4 px-6 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all transform hover:scale-105"
          disabled={selectedNetworks.length === 0}
        >
          <Search className="w-5 h-5" />
          Scan Selected Networks
        </Button>
      </CardContent>
    </Card>
  );
}
