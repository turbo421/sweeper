import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { ConnectedWallet } from "@/types/wallet";
import {
  Wallet,
  Home,
  Repeat,
  Merge,
  Activity,
  Settings,
  X
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  connectedWallets: ConnectedWallet[];
}

export default function Sidebar({ isOpen, onClose, connectedWallets }: SidebarProps) {
  const navItems = [
    { icon: Home, label: "Dashboard", active: true, href: "/" },
    { icon: Repeat, label: "Sweep Wallets", active: false, href: "/sweep" },
    { icon: Merge, label: "Consolidate Assets", active: false, href: "/consolidate" },
    { icon: Activity, label: "Transaction History", active: false, href: "/transactions" },
    { icon: Settings, label: "Settings", active: false, href: "/settings" }
  ];

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside className={cn(
        "fixed left-0 top-0 h-screen w-72 bg-dark-blue border-r border-royal-blue z-50 transform transition-transform duration-300 ease-in-out shadow-2xl",
        isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Close button for mobile */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 lg:hidden"
          onClick={onClose}
        >
          <X className="w-6 h-6" />
        </Button>

        {/* Header */}
        <div className="p-6 border-b border-royal-blue">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Wallet className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Wallet Sweeper</h1>
              <p className="text-sm text-gray-400">Asset Manager</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 p-4">
          <nav className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Button
                  key={item.label}
                  variant="ghost"
                  className={cn(
                    "nav-item w-full justify-start gap-3 p-3 h-auto text-gray-300 hover:bg-gray-700/30 hover:text-primary",
                    item.active && "nav-item active bg-primary/10 text-primary"
                  )}
                >
                  <Icon className="w-5 h-5" />
                  {item.label}
                </Button>
              );
            })}
          </nav>

          {/* Connected Wallets Section */}
          <div className="mt-8">
            <h3 className="text-sm font-semibold text-gray-400 mb-4 uppercase tracking-wide px-3">
              Connected Wallets
            </h3>
            <div className="space-y-2">
              {connectedWallets.length === 0 ? (
                <p className="text-sm text-gray-500 px-3">No wallets connected</p>
              ) : (
                connectedWallets.map((wallet, index) => (
                  <div
                    key={wallet.address}
                    className="wallet-item p-3 bg-gray-700/30 rounded-lg border border-gray-600/50 hover:border-primary/50 cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white",
                        index === 0 && "bg-gradient-to-br from-blue-500 to-purple-600",
                        index === 1 && "bg-gradient-to-br from-green-500 to-teal-600",
                        index === 2 && "bg-gradient-to-br from-orange-500 to-red-600"
                      )}>
                        W{index + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate">
                          {wallet.name}
                        </p>
                        <p className="text-xs text-gray-400 truncate">
                          {`${wallet.address.slice(0, 6)}...${wallet.address.slice(-4)}`}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-green-400">
                          {parseFloat(wallet.balance).toFixed(4)} {wallet.network}
                        </p>
                        <Badge variant="secondary" className="text-xs">
                          {wallet.network}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </ScrollArea>
      </aside>
    </>
  );
}
