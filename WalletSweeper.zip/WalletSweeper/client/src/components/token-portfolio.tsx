import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { TokenBalance } from "@/types/wallet";
import { 
  Coins, 
  RefreshCw, 
  TrendingUp, 
  TrendingDown,
  Activity
} from "lucide-react";

interface TokenPortfolioProps {
  tokens: TokenBalance[];
  isLoading: boolean;
  onRefresh: () => void;
  onSweepToken: (token: TokenBalance) => void;
}

export default function TokenPortfolio({
  tokens,
  isLoading,
  onRefresh,
  onSweepToken
}: TokenPortfolioProps) {
  const [refreshing, setRefreshing] = useState(false);

  const { data: transactions = [] } = useQuery({
    queryKey: ['/api/transactions'],
  });

  const handleRefresh = async () => {
    setRefreshing(true);
    await onRefresh();
    setTimeout(() => setRefreshing(false), 1000);
  };

  const getNetworkColor = (network: string) => {
    const colors: Record<string, string> = {
      'ethereum': 'bg-gray-600',
      'bsc': 'bg-yellow-600',
      'polygon': 'bg-purple-600'
    };
    return colors[network] || 'bg-gray-500';
  };

  const getPriceChangeColor = (change?: number) => {
    if (!change) return "text-gray-400";
    return change > 0 ? "text-green-400" : "text-red-400";
  };

  const getPriceChangeIcon = (change?: number) => {
    if (!change) return null;
    return change > 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />;
  };

  if (isLoading) {
    return (
      <Card className="bg-gradient-to-br from-dark-blue to-royal-blue border-gray-600/30 shadow-2xl">
        <CardHeader>
          <div className="flex items-center justify-between">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-10 w-24" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-8">
      {/* Token Portfolio Overview */}
      <Card className="bg-gradient-to-br from-dark-blue to-royal-blue border-gray-600/30 shadow-2xl">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-bold flex items-center gap-3 text-white">
              <Coins className="w-7 h-7 text-primary" />
              Token Portfolio Overview
            </CardTitle>
            <Button
              onClick={handleRefresh}
              variant="outline"
              size="sm"
              className="bg-primary/20 text-primary border-primary/30 hover:bg-primary hover:text-white"
              disabled={refreshing}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {tokens.length === 0 ? (
            <div className="text-center py-12">
              <Coins className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-300 mb-2">No Tokens Found</h3>
              <p className="text-gray-400 mb-6">
                Connect a wallet and scan networks to discover your tokens
              </p>
              <Button
                onClick={handleRefresh}
                className="bg-primary hover:bg-primary/90 text-white"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Scan for Tokens
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-b border-gray-600/50">
                    <TableHead className="text-gray-400 font-medium">Token</TableHead>
                    <TableHead className="text-gray-400 font-medium">Balance</TableHead>
                    <TableHead className="text-gray-400 font-medium">Value</TableHead>
                    <TableHead className="text-gray-400 font-medium">Networks</TableHead>
                    <TableHead className="text-gray-400 font-medium">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tokens.map((token, index) => (
                    <TableRow 
                      key={`${token.symbol}-${token.network}-${index}`}
                      className="token-row border-b border-gray-700/30 hover:bg-gray-700/20"
                    >
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center font-bold text-white">
                            {token.symbol.charAt(0)}
                          </div>
                          <div>
                            <p className="font-semibold text-white">{token.name}</p>
                            <p className="text-sm text-gray-400">{token.symbol}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-semibold text-white">
                            {parseFloat(token.balance).toFixed(4)} {token.symbol}
                          </p>
                          <p className="text-sm text-gray-400">Single wallet</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-semibold text-green-400">
                            ${token.usdValue || '0.00'}
                          </p>
                          <div className={`text-sm flex items-center gap-1 ${getPriceChangeColor(token.priceChange)}`}>
                            {getPriceChangeIcon(token.priceChange)}
                            {token.priceChange ? `${token.priceChange > 0 ? '+' : ''}${token.priceChange}%` : '0.0%'}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className={`${getNetworkColor(token.network)} text-white text-xs`}
                        >
                          {token.network.toUpperCase()}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          onClick={() => onSweepToken(token)}
                          size="sm"
                          className="bg-primary hover:bg-primary/90 text-white px-3 py-1 text-sm font-medium"
                        >
                          Sweep
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Transactions */}
      <Card className="bg-gradient-to-br from-dark-blue to-royal-blue border-gray-600/30 shadow-2xl">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-bold flex items-center gap-3 text-white">
              <Activity className="w-7 h-7 text-primary" />
              Recent Transactions
            </CardTitle>
            <Button variant="link" className="text-primary hover:text-primary/80">
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <div className="text-center py-8">
              <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">No recent transactions</p>
            </div>
          ) : (
            <div className="space-y-4">
              {transactions.slice(0, 5).map((tx: any, index: number) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 bg-gray-700/20 rounded-xl border border-gray-600/30 hover:border-primary/30 transition-all"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-green-500" />
                    </div>
                    <div>
                      <p className="font-semibold text-white">
                        {tx.status === 'confirmed' ? 'Sweep Completed' : 'Transaction Pending'}
                      </p>
                      <p className="text-sm text-gray-400">
                        {tx.network} → Main Wallet
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-green-400">
                      +{tx.amount} {tx.tokenSymbol}
                    </p>
                    <p className="text-sm text-gray-400">
                      {new Date(tx.createdAt).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
