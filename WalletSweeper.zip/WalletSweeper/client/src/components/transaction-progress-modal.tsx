import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Loader2, 
  Check, 
  Clock, 
  AlertCircle,
  ExternalLink
} from "lucide-react";

interface TransactionProgressModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
}

export default function TransactionProgressModal({ 
  isOpen, 
  onClose, 
  status = 'pending' 
}: TransactionProgressModalProps) {
  const getStatusInfo = () => {
    switch (status) {
      case 'pending':
        return {
          title: "Processing Transaction",
          description: "Please wait while we sweep your assets. This may take a few minutes.",
          icon: <Loader2 className="w-10 h-10 text-primary animate-spin" />
        };
      case 'in_progress':
        return {
          title: "Executing Sweep",
          description: "Your assets are being transferred. Please do not close this window.",
          icon: <Loader2 className="w-10 h-10 text-blue-500 animate-spin" />
        };
      case 'completed':
        return {
          title: "Sweep Completed",
          description: "All assets have been successfully transferred to your destination wallet.",
          icon: <Check className="w-10 h-10 text-green-500" />
        };
      case 'failed':
        return {
          title: "Transaction Failed",
          description: "The sweep operation failed. Please try again or contact support.",
          icon: <AlertCircle className="w-10 h-10 text-red-500" />
        };
      default:
        return {
          title: "Processing...",
          description: "Please wait...",
          icon: <Clock className="w-10 h-10 text-gray-500" />
        };
    }
  };

  const statusInfo = getStatusInfo();

  const progressSteps = [
    {
      id: 'connect',
      title: 'Wallet connected and authorized',
      status: 'completed'
    },
    {
      id: 'execute',
      title: 'Executing sweep transactions...',
      status: status === 'pending' || status === 'in_progress' ? 'in_progress' : status
    },
    {
      id: 'finalize',
      title: 'Finalizing transfers',
      status: status === 'completed' ? 'completed' : 'pending'
    }
  ];

  const getStepIcon = (stepStatus: string) => {
    switch (stepStatus) {
      case 'completed':
        return <Check className="w-4 h-4 text-white" />;
      case 'in_progress':
        return <Loader2 className="w-4 h-4 text-white animate-spin" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStepBgColor = (stepStatus: string) => {
    switch (stepStatus) {
      case 'completed':
        return 'bg-green-500';
      case 'in_progress':
        return 'bg-primary';
      default:
        return 'bg-gray-600';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={status === 'completed' || status === 'failed' ? onClose : undefined}>
      <DialogContent 
        className="sm:max-w-md bg-dark-blue border-gray-600/50"
        hideCloseButton={status === 'pending' || status === 'in_progress'}
      >
        <div className="text-center">
          <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
            {statusInfo.icon}
          </div>
          
          <h3 className="text-2xl font-bold mb-4 text-white">
            {statusInfo.title}
          </h3>
          <p className="text-gray-400 mb-8">
            {statusInfo.description}
          </p>
          
          {/* Progress Steps */}
          <div className="space-y-4 mb-8">
            {progressSteps.map((step) => (
              <div 
                key={step.id}
                className={`flex items-center gap-3 p-3 rounded-lg bg-gray-700/30 ${
                  step.status === 'in_progress' ? 'ring-2 ring-primary/50' : ''
                }`}
              >
                <div className={`w-6 h-6 ${getStepBgColor(step.status)} rounded-full flex items-center justify-center`}>
                  {getStepIcon(step.status)}
                </div>
                <span className={`text-sm ${step.status === 'pending' ? 'text-gray-400' : 'text-white'}`}>
                  {step.title}
                </span>
              </div>
            ))}
          </div>
          
          {/* Transaction Hash */}
          {(status === 'in_progress' || status === 'completed') && (
            <div className="bg-gray-700/30 rounded-xl p-4 mb-6">
              <p className="text-xs text-gray-400 mb-1">Transaction Hash:</p>
              <p className="text-sm font-mono bg-gray-800 px-3 py-2 rounded break-all text-white">
                0x1234567890abcdef1234567890abcdef12345678
              </p>
              <Button
                variant="link"
                size="sm"
                className="text-primary text-xs mt-2 hover:text-primary/80 p-0"
              >
                View on Explorer
                <ExternalLink className="w-3 h-3 ml-1" />
              </Button>
            </div>
          )}

          {/* Status Badge */}
          <div className="mb-6">
            <Badge 
              className={`px-4 py-2 text-sm font-medium ${
                status === 'completed' ? 'bg-green-500/20 text-green-400' :
                status === 'failed' ? 'bg-red-500/20 text-red-400' :
                status === 'in_progress' ? 'bg-blue-500/20 text-blue-400' :
                'bg-yellow-500/20 text-yellow-400'
              }`}
            >
              {status === 'completed' && 'Transaction Completed'}
              {status === 'failed' && 'Transaction Failed'}
              {status === 'in_progress' && 'In Progress'}
              {status === 'pending' && 'Pending Confirmation'}
            </Badge>
          </div>

          {/* Action Buttons */}
          {status === 'completed' && (
            <Button
              className="w-full bg-primary hover:bg-primary/90 text-white"
              onClick={onClose}
            >
              <Check className="w-4 h-4 mr-2" />
              Done
            </Button>
          )}

          {status === 'failed' && (
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1 bg-gray-600 hover:bg-gray-500 text-white border-gray-500"
                onClick={onClose}
              >
                Close
              </Button>
              <Button
                className="flex-1 bg-primary hover:bg-primary/90 text-white"
                onClick={() => {
                  // Retry logic
                  onClose();
                }}
              >
                Retry
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
