import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  address: text("address").notNull(),
  name: text("name").notNull(),
  network: text("network").notNull(),
  balance: decimal("balance", { precision: 20, scale: 8 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tokens = pgTable("tokens", {
  id: serial("id").primaryKey(),
  walletId: integer("wallet_id").references(() => wallets.id),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  contractAddress: text("contract_address"),
  balance: decimal("balance", { precision: 20, scale: 8 }),
  decimals: integer("decimals").default(18),
  network: text("network").notNull(),
  usdValue: decimal("usd_value", { precision: 20, scale: 2 }),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  hash: text("hash").notNull(),
  fromAddress: text("from_address").notNull(),
  toAddress: text("to_address").notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }),
  tokenSymbol: text("token_symbol"),
  network: text("network").notNull(),
  status: text("status").notNull(), // pending, confirmed, failed
  gasUsed: decimal("gas_used", { precision: 20, scale: 8 }),
  gasPrice: decimal("gas_price", { precision: 20, scale: 8 }),
  blockNumber: integer("block_number"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sweepOperations = pgTable("sweep_operations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  sourceWallets: jsonb("source_wallets").notNull(), // array of wallet addresses
  destinationWallet: text("destination_wallet").notNull(),
  networks: jsonb("networks").notNull(), // array of network names
  status: text("status").notNull(), // initiated, in_progress, completed, failed
  totalValue: decimal("total_value", { precision: 20, scale: 2 }),
  transactionHashes: jsonb("transaction_hashes"), // array of transaction hashes
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertWalletSchema = createInsertSchema(wallets).omit({
  id: true,
  createdAt: true,
});

export const insertTokenSchema = createInsertSchema(tokens).omit({
  id: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export const insertSweepOperationSchema = createInsertSchema(sweepOperations).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertWallet = z.infer<typeof insertWalletSchema>;
export type Wallet = typeof wallets.$inferSelect;

export type InsertToken = z.infer<typeof insertTokenSchema>;
export type Token = typeof tokens.$inferSelect;

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

export type InsertSweepOperation = z.infer<typeof insertSweepOperationSchema>;
export type SweepOperation = typeof sweepOperations.$inferSelect;
