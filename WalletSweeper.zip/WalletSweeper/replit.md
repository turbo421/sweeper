# Crypto Wallet Sweeper Application

## Overview

This is a full-stack cryptocurrency wallet management and sweeping application built with React, Express, and TypeScript. The application allows users to connect their wallets, view token balances across multiple blockchain networks, and perform sweep operations to consolidate assets.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Styling**: Tailwind CSS with custom MetaMask-inspired dark theme
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Web3 Integration**: Ethers.js for blockchain interactions

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Session Management**: Connect-pg-simple for PostgreSQL-backed sessions
- **Development**: Hot module replacement with Vite integration
- **Build**: ESBuild for server bundling

### Database Design
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Located in `shared/schema.ts` for type sharing between client and server
- **Tables**:
  - `users`: User authentication and profiles
  - `wallets`: Connected wallet addresses and metadata
  - `tokens`: Token balances and metadata per wallet
  - `transactions`: Transaction history and status tracking
  - `sweep_operations`: Sweep operation records and status

## Key Components

### Web3 Integration
- MetaMask connection support with automatic network detection
- Multi-network support (Ethereum, BSC, Polygon)
- Token detection across supported networks
- Real-time balance updates and price tracking

### Wallet Management
- Multiple wallet connection support
- Network-specific wallet tracking
- Balance monitoring across all connected wallets
- Token portfolio aggregation

### Sweep Operations
- Cross-network asset sweeping
- Gas estimation and optimization
- Transaction progress tracking
- Batch transaction handling

### User Interface
- Responsive design with mobile-first approach
- Dark theme optimized for crypto applications
- Real-time data updates
- Interactive modals for wallet connection and sweep confirmation

## Data Flow

1. **Wallet Connection**: User connects MetaMask → Frontend detects wallets → Backend stores wallet data
2. **Token Detection**: Frontend scans networks → Detects token balances → Updates backend records
3. **Portfolio Display**: Backend aggregates data → Frontend displays unified portfolio view
4. **Sweep Operations**: User selects assets → Frontend calculates gas → Backend executes transactions
5. **Status Updates**: Real-time transaction monitoring → Progress updates via UI

## External Dependencies

### Blockchain Infrastructure
- **RPC Providers**: Infura, BSC RPC, Polygon RPC for network connectivity
- **Web3 Libraries**: Ethers.js for blockchain interactions
- **Network Support**: Ethereum mainnet, BSC, Polygon with extensible architecture

### Database
- **Neon Database**: Serverless PostgreSQL provider
- **Connection**: Uses `@neondatabase/serverless` for optimal performance

### UI/UX Libraries
- **Component Library**: Extensive use of Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Icons**: Lucide React for consistent iconography
- **Animations**: CSS-based animations with Tailwind utilities

## Deployment Strategy

### Development Environment
- **Replit Integration**: Configured for Replit deployment with `.replit` configuration
- **Hot Reload**: Vite dev server with Express middleware integration
- **Database**: Automatic PostgreSQL provisioning in Replit environment

### Production Build
- **Client Build**: Vite builds React app to `dist/public`
- **Server Build**: ESBuild bundles Express server to `dist/index.js`
- **Static Serving**: Express serves built client files in production

### Environment Configuration
- **Database**: Requires `DATABASE_URL` environment variable
- **Networks**: RPC URLs configurable via environment variables
- **Deployment**: Replit autoscale deployment with port 5000 → 80 mapping

## Changelog

Changelog:
- June 19, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.